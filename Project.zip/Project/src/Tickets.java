import java.util.Scanner;

public class Tickets {

	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        boolean[] seats = new boolean[10];
        int firstClassSeat = 0;
        int economyClassSeat = 5;
        int validatingNumber;
        
        while(true) {
            if(firstClassSeat>4 && economyClassSeat>9 ){
                System.out.println("The plane is full! Check our other services for booking another flight.");
                   
            }
                System.out.println("Welcome to the Java Airlines! Please follow the instructions below to book your flight.");
                System.out.println("Please input 1 for buying First Class Ticket");
                System.out.println("Please input 2 for buying Economy Class Ticket");
                System.out.println("Please input 3 for Ticket Validation");
                System.out.print("Your choice will be shown here: ");
                int choice = scan.nextInt();
               

                if(firstClassSeat<5||economyClassSeat<10) {

                    if (choice == 1) {


                    if (FirstClassFull(firstClassSeat) == false) {
                        seats[firstClassSeat]=true;
                        System.out.println("You've bought a First Class Ticket. Your seat is #" + (firstClassSeat+1));

                        firstClassSeat++;
                    }
                    else {
                        int choice2;
                        System.out.println("Our First Class Services are full, do you prefer Economy Class?");
                        System.out.print("1. Yes 2. No Your choice will be shown here: ");
                        choice2 = scan.nextInt();
                        if(choice2==1){
                            seats[economyClassSeat]=true;
                            System.out.println("You've bought an Economy Class Ticket. Your seat is #" + (economyClassSeat+1));
                            economyClassSeat++;
                        }
                        else {

                            System.out.println("Next flight is going to leave in 3 hours.");
                        }
                    }
                }
                if (choice == 2) {
                    int choice3;
                    if (SecondClassFull(economyClassSeat) == false) {
                        seats[economyClassSeat]=true;
                        System.out.println("Thank you for your corporation. Your seat number is #" + (economyClassSeat+1));
                        economyClassSeat++;

                    }
                    else {

                        System.out.println("We have fulfilled our Economy Class Services, do you prefer First Class?");
                        System.out.print("1. Yes 2. No Your choice will be shown here:");
                        choice3=scan.nextInt();
                        if(choice3==1){
                            System.out.println("Thank you for your corporation. Your seat number is #" + (firstClassSeat+1));
                            seats[firstClassSeat]=true;
                            firstClassSeat++;

                        }
                    }
                }
            }


            if(choice==3){
                System.out.print("Enter seat ID to validate: ");
                validatingNumber = scan.nextInt();
                try{


                    validatingTicketBySeat(seats,validatingNumber);
                } catch (ArrayIndexOutOfBoundsException e){
                	
                    System.out.println("We do not have any seat with this ID.");

                }
            }
        }
    }

    public static boolean FirstClassFull(int firstClassSeat){
        if(firstClassSeat>4){
            return true;

        }
        else{
            return false;
        }

    }
    public static boolean SecondClassFull(int economyClassSeat){
        if(economyClassSeat>9){
            return true;
        }
        else{
            return false;
        }
    }
    public static void  validatingTicketBySeat(boolean[] seats,int seatID){
        if(seats[seatID-1]){
            System.out.println("This ticket has been sold.");

        }
        else{

            System.out.println("This ticket is available!");
        }
    }
}
